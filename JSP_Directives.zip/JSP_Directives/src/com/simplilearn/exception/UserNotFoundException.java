package com.simplilearn.exception;

public class UserNotFoundException  extends  Exception{

}

package com.ekart.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ekart.entity.Customer;
import com.ekart.repository.HibernateUtil;

/**
 * Servlet implementation class CustomerController
 */
@WebServlet("/CustomerController")
public class CustomerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		

		
		out.print("<h1>Customer Controller</h1>");
		
		String cname =	request.getParameter("cname");
		
		SessionFactory factory = HibernateUtil.getSessionFactory();

		Session session = factory.openSession();
		
				session.beginTransaction();
				
				Customer customer = new Customer();
				
					customer.setCname(cname);

						session.persist(customer);
						
				session.getTransaction().commit();		
				
				
					HttpSession httpSession = request.getSession();
					
						httpSession.setAttribute("customer", customer);
						
					RequestDispatcher rd =	request.getRequestDispatcher("success.jsp");
		
						rd.include(request, response);
						

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

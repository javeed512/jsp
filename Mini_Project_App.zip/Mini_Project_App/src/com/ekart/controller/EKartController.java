package com.ekart.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ekart.entity.Customer;
import com.ekart.entity.Product;
import com.ekart.repository.HibernateUtil;

/**
 * Servlet implementation class EKartController
 */
@WebServlet("/EKartController")
public class EKartController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor.
	 */
	public EKartController() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();

		out.print("<h1>Welcome to EKart</h1> ");

		SessionFactory factory = HibernateUtil.getSessionFactory();

		Session session = factory.openSession();

		out.print(session);

		
		Product product1 = new Product();
		product1.setPname("Mobile");
		product1.setPrice(20000);

		Product product2 = new Product();
		product2.setPname("Books");
		product2.setPrice(3000);
		
		
		Product product3 = new Product();
		product3.setPname("Clothes");
		product3.setPrice(1200);
		
		
		List<Product> productCart = new ArrayList<Product>();
		
			productCart.add(product1);
			productCart.add(product2);
			productCart.add(product3);
		
		Customer customer1 = new Customer();

		customer1.setCname("Javeed");
		customer1.setProductList(productCart);
		
		session.beginTransaction();
		
		session.persist(customer1);
		
		session.getTransaction().commit();
		
		out.print("<h1>Customer and Products Added</h1>");


	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

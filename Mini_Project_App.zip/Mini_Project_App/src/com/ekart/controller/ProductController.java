package com.ekart.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ekart.entity.Customer;
import com.ekart.entity.Product;
import com.ekart.repository.HibernateUtil;

/**
 * Servlet implementation class ProductController
 */
@WebServlet("/ProductController")
public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		

		
		SessionFactory factory = HibernateUtil.getSessionFactory();

		Session session = factory.openSession();
		
				
		
		out.print("<h1>Product Added Succcesfully...</h1>");
		
		HttpSession httpSession = request.getSession();
		
		Customer customer = (Customer) httpSession.getAttribute("customer");
		
		String pname =	request.getParameter("pname");
		double price =	Double.parseDouble(request.getParameter("price"));
		
		/*
		 * Customer customer = (Customer) httpSession.getAttribute("customer");
		 * 
		 * Product product = new Product();
		 * 
		 * product.setPname(pname); product.setPrice(price);
		 * 
		 * List<Product> productList = new ArrayList();
		 * 
		 * productList.add(product);
		 * 
		 * customer.setProductList(productList);
		 */
			
		Product product = new Product();
		 
		  product.setPname(pname); 
		  product.setPrice(price);
		  product.setCid(customer.getCid());
		  
			
			session.beginTransaction();
			
				session.persist(product);
				
				session.getTransaction().commit();
				
				
				
			
				
				
				
				RequestDispatcher rd =	request.getRequestDispatcher("success.jsp");
				
				rd.include(request, response);
				

					
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

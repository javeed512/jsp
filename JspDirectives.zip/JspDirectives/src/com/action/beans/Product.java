package com.action.beans;

public class Product {
	
	private String pname;
	
	@Override
	public String toString() {
		return "Product [pname=" + pname + ", price=" + price + "]";
	}

	private int price;

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
	

}
